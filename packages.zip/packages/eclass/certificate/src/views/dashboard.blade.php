<!DOCTYPE html>
<html lang="en">
<head>
  <title>Certificate Module</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Certificate Dashboard</h2>
  <a href="{{ route('cource.certificate.sample') }}" class="btn btn-info" role="button">Sample Certificate</a>
  <a href="{{ route('courec.create.certificate') }}" class="btn btn-info" role="button">Create Certificate</a>
   <a href="{{ route('cource.preview.certificate') }}" class="btn btn-info" role="button">Preview Certificate</a>
</div>

</body>
</html>
