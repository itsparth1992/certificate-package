<!DOCTYPE html>
<html lang="en">
<head>
  <title>Create Cource Certificate</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<style type="text/css">
  /* css for side menu start */

.form-group {
    margin-left: 30px;
    margin-top: 10px;
}
.vertical-menu {
  width: 200px;
}

.vertical-menu a {
  background-color: #eee;
  color: black;
  display: block;
  padding: 12px;
  text-decoration: none;
}

.vertical-menu a:hover {
  background-color: #ccc;
}

.vertical-menu a.active {
  background-color: #4CAF50;
  color: white;
}
/* css for side menu end */

/* css for certificate design start */

.cirtificate-border-one { 
    font-family: "Times New Roman", Times, serif; 
    border: 15px solid ;
    border-top-color:  #40444a;
    border-right-color: #0284a2;
    border-bottom-color: #0284a2;
    border-left-color: #40444a;
    padding:20px;
    background-color: #fff;
  
  }
  .cirtificate-border-one-sub { 
    font-family: "Times New Roman", Times, serif; 
    border: 7px solid ;
    border-top-color:  #0284a2;
    border-right-color: #40444a;
    border-bottom-color: #40444a;
    border-left-color: #0284a2;
    padding:20px;
    background-color: #fff;
    margin-top: -29px;
    margin-left: -29px;
    margin-bottom: -29px;
    margin-right: -29px;
  
  }
  .cirtificate-border-two {  
    border: 2px solid #0284a2;
    padding:20px;
  }

  .cirtificate-border-two-sub {  
    border: 2px solid #0284a2;
    padding:20px;
    margin-top: -26px;
    margin-left: -26px;
    margin-bottom: -26px;
    margin-right: -26px;
  }
  .cirtificate-heading {
    font-size:50px; 
    font-weight:bold;
    font-style: italic;
    margin-bottom: 20px;
  }
  .cirtificate-detail {
    margin-bottom: 20px;
    font-size: 30px;
  }
  .cirtificate-instructor {
    font-family: 'Great Vibes';
    font-style: normal;
    font-size: 20px;
    margin: 0 auto;
    text-align: center;
  }
  .cirtificate-logo img {
    width: 125px;
  }
  
  .img-fluid {
      max-width: 100%;
      height: auto;
  }
  .box-body img {
      height: 39px;
  }
  
/* css for certificate design end */

/* toggle button setting start */
/* The switch - the box around the slider */

.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
/* toggle button setting end  */

</style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <div class="col-sm-4">
       <div class="vertical-menu">
                    <a href="{{ route('cource.certificate.dashboard') }}">Dashboard</a>
                    <a href="#" onclick="showDiv1()">Add Logo</a>
                    <a href="#" onclick="showDiv2()">Add Title</a>
                    <a href="#" onclick="showDiv8()">Add Certificate Background</a>
                    <a href="#" onclick="showDiv11()">Add Signature</a>
                    <a href="#" onclick="showDiv3()">Add Content 1</a>
                    <a href="#" onclick="showDiv9()">Add Content 2</a>
                    <a href="#" onclick="showDiv10()">Add Content 3</a>
                    <a href="#" onclick="showDiv4()">Add Outer Border</a>
                    <a href="#" onclick="showDiv5()">Add Outer Sub Border</a>
                    <a href="#" onclick="showDiv6()">Add Inner Border</a>
                    <a href="#" onclick="showDiv7()">Add Inner Sub Border</a>  
          </div>
    </div>
    <div class="col-sm-8">

                  <div>
                    @if(session()->has('message'))
                    <div class="alert alert-success">
                    {{ session()->get('message') }}
                    </div>
                    @endif
                  </div>
                  
                  <!-- == Logo start === -->
                <div id="welcomeDiv1"  style="display:none;">
                    <div class="row">
                    <div class="col-md-6">
                    <form class="form-inline" action="{{ route('add.certificate.logostyle') }}" method="post" enctype="multipart/form-data">
                      @csrf
                    
                    <div class="form-group">
                    <label for="fname">Add Logo:</label><br>
                    <input type="hidden" id="certititle" name="logo_style" value="logo_style">
                    <input type="file" id="certititle" name="logomage"><br>
                    </div><br>

                    <div class="form-group">
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo1"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br><br>

                    <div id="demo1" class="collapse">

                        <div class="form-group">
                          <label for="fname">Width:</label><br>
                              <select class="form-control" name="titlewidth">
                                <option value="" >Select</option>
                                <option value="1px" >1px</option>
                                <option value="2px">2px</option>
                                <option value="3px">3px</option>
                                <option value="4px">4px</option>
                                <option value="5px" >5px</option>
                                <option value="6px">6px</option>
                                <option value="7px">7px</option>
                                <option value="8px">8px</option>
                                <option value="9px" >9px</option>
                                <option value="10px">10px</option>
                                <option value="11px">11px</option>
                                <option value="12px">12px</option>
                                <option value="13px" >13px</option>
                                <option value="14px">14px</option>
                                <option value="15px">15px</option>
                                <option value="16px">16px</option>
                                <option value="17px" >17px</option>
                                <option value="18px">18px</option>
                                <option value="19px">19px</option>
                                <option value="20px">20px</option>
                                <option value="21px" >21px</option>
                                <option value="22px">22px</option>
                                <option value="23px">23px</option>
                                <option value="24px">24px</option>
                                <option value="25px" >25px</option>
                                <option value="26px">26px</option>
                                <option value="27px">27px</option>
                                <option value="28px" >28px</option>
                                <option value="29px">29px</option>
                                <option value="30px">30px</option>
                                <option value="31px">31px</option>
                                <option value="32px" >32px</option>
                                <option value="33px">33px</option>
                                <option value="34px">34px</option>
                                <option value="35px">35px</option>
                            </select>
                      </div>
                      <div class="form-group">
                            <label for="fname">Hieght:</label><br>
                            <select class="form-control" name="titlehight">
                                <option value="" >Select</option>
                                <option value="1px" >1px</option>
                                <option value="2px">2px</option>
                                <option value="3px">3px</option>
                                <option value="4px">4px</option>
                                <option value="5px" >5px</option>
                                <option value="6px">6px</option>
                                <option value="7px">7px</option>
                                <option value="8px">8px</option>
                                <option value="9px" >9px</option>
                                <option value="10px">10px</option>
                                <option value="11px">11px</option>
                                <option value="12px">12px</option>
                                <option value="13px" >13px</option>
                                <option value="14px">14px</option>
                                <option value="15px">15px</option>
                                <option value="16px">16px</option>
                                <option value="17px" >17px</option>
                                <option value="18px">18px</option>
                                <option value="19px">19px</option>
                                <option value="20px">20px</option>
                                <option value="21px" >21px</option>
                                <option value="22px">22px</option>
                                <option value="23px">23px</option>
                                <option value="24px">24px</option>
                                <option value="25px" >25px</option>
                                <option value="26px">26px</option>
                                <option value="27px">27px</option>
                                <option value="28px" >28px</option>
                                <option value="29px">29px</option>
                                <option value="30px">30px</option>
                                <option value="31px">31px</option>
                                <option value="32px" >32px</option>
                                <option value="33px">33px</option>
                                <option value="34px">34px</option>
                                <option value="35px">35px</option>
                            </select>
                      </div>
                      <div class="form-group">
                        <label for="fname">Margin</label><br>
                        <select class="form-control" name="margin">
                            <option value="" >Select</option>
                            <option value="1px" >1px</option>
                            <option value="2px">2px</option>
                            <option value="3px">3px</option>
                            <option value="4px">4px</option>
                            <option value="5px" >5px</option>
                            <option value="6px">6px</option>
                            <option value="7px">7px</option>
                            <option value="8px">8px</option>
                            <option value="9px" >9px</option>
                            <option value="10px">10px</option>
                            <option value="11px">11px</option>
                            <option value="12px">12px</option>
                            <option value="13px" >13px</option>
                            <option value="14px">14px</option>
                            <option value="15px">15px</option>
                            <option value="16px">16px</option>
                            <option value="17px" >17px</option>
                            <option value="18px">18px</option>
                            <option value="19px">19px</option>
                            <option value="20px">20px</option>
                            <option value="21px" >21px</option>
                            <option value="22px">22px</option>
                            <option value="23px">23px</option>
                            <option value="24px">24px</option>
                            <option value="25px" >25px</option>
                            <option value="26px">26px</option>
                            <option value="27px">27px</option>
                            <option value="28px" >28px</option>
                            <option value="29px">29px</option>
                            <option value="30px">30px</option>
                            <option value="31px">31px</option>
                            <option value="32px" >32px</option>
                            <option value="33px">33px</option>
                            <option value="34px">34px</option>
                            <option value="35px">35px</option>
                          </select>
                      </div>
                      <div class="form-group">
                        <label for="fname">Margin Top:</label><br>
                        <select class="form-control" name="margintop">
                          <option value="" >Select</option>
                          <option value="1px" >1px</option>
                          <option value="2px">2px</option>
                          <option value="3px">3px</option>
                          <option value="4px">4px</option>
                          <option value="5px" >5px</option>
                          <option value="6px">6px</option>
                          <option value="7px">7px</option>
                          <option value="8px">8px</option>
                          <option value="9px" >9px</option>
                          <option value="10px">10px</option>
                          <option value="11px">11px</option>
                          <option value="12px">12px</option>
                          <option value="13px" >13px</option>
                          <option value="14px">14px</option>
                          <option value="15px">15px</option>
                          <option value="16px">16px</option>
                          <option value="17px" >17px</option>
                          <option value="18px">18px</option>
                          <option value="19px">19px</option>
                          <option value="20px">20px</option>
                          <option value="21px" >21px</option>
                          <option value="22px">22px</option>
                          <option value="23px">23px</option>
                          <option value="24px">24px</option>
                          <option value="25px" >25px</option>
                          <option value="26px">26px</option>
                          <option value="27px">27px</option>
                          <option value="28px" >28px</option>
                          <option value="29px">29px</option>
                          <option value="30px">30px</option>
                          <option value="31px">31px</option>
                          <option value="32px" >32px</option>
                          <option value="33px">33px</option>
                          <option value="34px">34px</option>
                          <option value="35px">35px</option>
                          </select>
                      </div>
                      <div class="form-group">
                        <label for="fname">Margin Bottom:</label><br>
                        <select class="form-control" name="marginbottom">
                            <option value="" >Select</option>
                            <option value="1px" >1px</option>
                            <option value="2px">2px</option>
                            <option value="3px">3px</option>
                            <option value="4px">4px</option>
                            <option value="5px" >5px</option>
                            <option value="6px">6px</option>
                            <option value="7px">7px</option>
                            <option value="8px">8px</option>
                            <option value="9px" >9px</option>
                            <option value="10px">10px</option>
                            <option value="11px">11px</option>
                            <option value="12px">12px</option>
                            <option value="13px" >13px</option>
                            <option value="14px">14px</option>
                            <option value="15px">15px</option>
                            <option value="16px">16px</option>
                            <option value="17px" >17px</option>
                            <option value="18px">18px</option>
                            <option value="19px">19px</option>
                            <option value="20px">20px</option>
                            <option value="21px" >21px</option>
                            <option value="22px">22px</option>
                            <option value="23px">23px</option>
                            <option value="24px">24px</option>
                            <option value="25px" >25px</option>
                            <option value="26px">26px</option>
                            <option value="27px">27px</option>
                            <option value="28px" >28px</option>
                            <option value="29px">29px</option>
                            <option value="30px">30px</option>
                            <option value="31px">31px</option>
                            <option value="32px" >32px</option>
                            <option value="33px">33px</option>
                            <option value="34px">34px</option>
                            <option value="35px">35px</option>
                        </select>
                      </div><br>

                  <div class="form-group">
                  <label for="fname">Margin Left:</label><br>
                  <select class="form-control" name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Margin Right:</label><br>
                  <select class="form-control" name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding:</label><br>
                  <select class="form-control" name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Top:</label><br>
                  <select class="form-control" name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Bottom:</label><br>
                  <select class="form-control" name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Left:</label><br>
                  <select class="form-control" name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Right:</label><br>
                  <select class="form-control" name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
  
                    </div>

                    <div class="form-group">
                    <input type="submit" value="save">
                    </div>
                    </form>
                    </div>
                    <div class="col-md-6">
                     <?php if(!empty($logostyle->logo_image)){?>
                  <img src="{{ asset('admin/certificate_pic/'.$logostyle->logo_image ) }}" class="img-fluid" alt="logo"><br><br>
                  <!-- <a href='delete-signature/{{ $logostyle->id }}' > <button class="btn btn-danger btn-sm" title="Delete">Delete</button></a> -->
                  <?php }?>
                    </div>
                    </div>


                </div>
                 <!-- == logo end === -->

                <!-- == title start === -->
                <div id="welcomeDiv2"  style="display:none;">
                  <form class="form-inline" action="{{ route('add.certificate.titlestyle') }}" method="post" enctype="multipart/form-data">
                  @csrf

                    <div class="form-group">
                    <label for="fname">Add Title to certificate:</label><br>
                    <input type="hidden" id="certititle" name="title_style" value="title_style">
                    <input type="text" name="certititle" style="width: 400px;"><br>
                    </div><br><br>

                    <div class="form-group">
                    <p style="color: red;">Manage Title design.</p>
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo2"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br><br>
                    <div id="demo2" class="collapse">
                    
                    <div class="form-group">
                    <label for="fname">Width:</label><br>
                    <select  name="titlewidth">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Hieght:</label><br>
                    <select  name="titlehight">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin</label><br>
                    <select  name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Top:</label><br>
                    <select  name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Bottom:</label><br>
                    <select  name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Left:</label><br>
                    <select  name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Right:</label><br>
                    <select  name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding:</label><br>
                    <select  name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Top:</label><br>
                    <select  name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Bottom:</label><br>
                    <select  name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Left:</label><br>
                    <select  name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Right:</label><br>
                    <select  name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Size:</label><br>
                    <select  name="font_size">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Weight:</label><br>
                    <select  name="font_weight">
                        <option value="" >Select</option>
                        <option value="normal" >normal</option>
                        <option value="bold">bold</option>
                        <option value="bolder">bolder</option>
                        <option value="lighter">lighter</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Style:</label><br>
                    <select  name="font_style">
                        <option value="" >Select</option>
                        <option value="normal" >normal</option>
                        <option value="italic">italic</option>
                        <option value="oblique">oblique</option>
                        <option value="initial">initial</option>
                        <option value="inherit" >inherit</option>
                    </select>
                    </div>
                
                    </div>
                    <div class="form-group">
                    <input type="submit" value="save">
                    </div>
                    </form>
                </div>
                <!-- == title end === -->

                <!-- == content block 1 start === -->
                <div id="welcomeDiv3"  style="display:none;">
                
                  <form class="form-inline" action="{{ route('add.certificate.contentstyle') }}" method="post" enctype="multipart/form-data">
                  @csrf
                    <div class="form-group">
                    <label for="fname">Content:</label><br>
                    <input type="hidden" id="certititle" name="Content_style" value="content_style"><br>
                    <textarea name="certicontent" rows="3" cols="100" placeholder="This is to certify that....."></textarea><br>
                    <p style="color: red;">Note: No need to write <span style="text-decoration: underline;">Student Name</span> because it will generate automatically.</p>
                    </div><br>

                    <div class="form-group">
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo3"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br>
                    
                    <div id="demo3" class="collapse">

                    <div class="form-group">
                    <label for="fname">Margin</label><br>
                    <select  name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Top:</label><br>
                    <select  name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Bottom:</label><br>
                    <select  name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Left:</label><br>
                    <select  name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Right:</label><br>
                    <select  name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding:</label><br>
                    <select  name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Top:</label><br>
                    <select  name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Bottom:</label><br>
                    <select  name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Left:</label><br>
                    <select  name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Right:</label><br>
                    <select  name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Size:</label><br>
                    <select  name="font_size">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    </div><br>
                    <div class="form-group">
                    <input type="submit" value="save">
                    </div>
                    </form>
                </div>
                <!-- === content block 1 end  ===-->

                <!-- == content block 2 start === -->
                 <div id="welcomeDiv9"  style="display:none;">
                    <form class="form-inline" action="{{ route('add.certificate.content2style') }}" method="post" enctype="multipart/form-data">
                        @csrf
                    <div class="form-group">
                    <label for="fname">Add Content:</label><br>
                    <input type="hidden" name="content_style_block2" value="content_style_block2"><br>
                    <textarea id="certititle" name="certicontent2" rows="3" cols="100" placeholder="successfully completed......"></textarea><br>
                    <p style="color: red;">Note: No need to write <span style="text-decoration: underline;">Cource Name</span> because it will generate automatically.</p>
                    </div><br><br>
                    <div class="form-group">
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo9"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br>
                    <div id="demo9" class="collapse">

                    <div class="form-group">
                    <label for="fname">Margin</label><br>
                    <select  name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Top:</label><br>
                    <select  name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Bottom:</label><br>
                    <select  name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Left:</label><br>
                    <select  name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Right:</label><br>
                    <select  name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding:</label><br>
                    <select  name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Top:</label><br>
                    <select  name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Bottom:</label><br>
                    <select  name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Left:</label><br>
                    <select  name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Right:</label><br>
                    <select  name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Size:</label><br>
                    <select  name="font_size">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Weight:</label><br>
                        <select  name="font_weight">
                        <option value="" >Select</option>
                        <option value="normal" >normal</option>
                        <option value="bold">bold</option>
                        <option value="bolder">bolder</option>
                        <option value="lighter">lighter</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Style:</label><br>
                    <select  name="font_style">
                        <option value="normal" >normal</option>
                        <option value="italic">italic</option>
                        <option value="oblique">oblique</option>
                        <option value="initial">initial</option>
                        <option value="inherit" >inherit</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Text Align:</label><br>
                    <select  name="text_align">
                        <option value="" >Select</option>
                        <option value="center" >center</option>
                        <option value="left">left</option>
                        <option value="right">right</option>
                        <option value="justify">justify</option>
                    </select>
                    </div>
                    
                    </div><br>
                    <div class="form-group">
                    <input type="submit" value="save">
                    </div>
                    </form>
                    </div>
                <!-- === content block 2 end  ===-->

                <!-- == content block 3 start === -->
                <div id="welcomeDiv10"  style="display:none;">
                
                    <form class="form-inline" action="{{ route('add.certificate.content3style') }}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                    <label for="fname">Content:</label><br>
                    <input type="hidden" name="content_style_block3" value="content_style_block3">
                    <textarea id="certititle" name="certicontent3" rows="3" cols="100" placeholder="online course on....."></textarea><br>
    
                    <p style="color: red;">Note: No need to write <span style="text-decoration: underline;">Date</span> because it will generate automatically.</p>
                    </div>
                    <div class="form-group">
                    <label for="fname">Add Symbol:</label><br>
                    <input type="text" name="symbol"><br>
                    </div><br><br>

                    <div class="form-group">
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo10"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br>
                    <div id="demo10" class="collapse">


                    <div class="form-group">
                    <label for="fname">Margin</label><br>
                    <select  name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Top:</label><br>
                    <select  name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Bottom:</label><br>
                    <select  name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Left:</label><br>
                    <select  name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Margin Right:</label><br>
                    <select  name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding:</label><br>
                    <select  name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Top:</label><br>
                    <select  name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Bottom:</label><br>
                    <select  name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Left:</label><br>
                    <select  name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Padding Right:</label><br>
                    <select  name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Size:</label><br>
                    <select  name="font_size">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Weight:</label><br>
                        <select  name="font_weight">
                        <option value="" >Select</option>
                        <option value="normal">normal</option>
                        <option value="bold">bold</option>
                        <option value="bolder">bolder</option>
                        <option value="lighter">lighter</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Font Style:</label><br>
                    <select  name="font_style">
                        <option value="normal" >normal</option>
                        <option value="italic">italic</option>
                        <option value="oblique">oblique</option>
                        <option value="initial">initial</option>
                        <option value="inherit" >inherit</option>
                    </select>
                    </div>

                    <div class="form-group">
                    <label for="fname">Text Align:</label><br>
                    <select  name="text_align">
                        <option value="" >Select</option>
                        <option value="center">center</option>
                        <option value="left">left</option>
                        <option value="right">right</option>
                        <option value="justify">justify</option>
                    </select>
                    </div>
                    
                    </div><br>
                    <div class="form-group">
                    <input type="submit" value="save">
                    </div>
                    </form>
              </div>
              <!-- === content block 3 end  ===-->

                <!-- == outer border start === -->
                <div id="welcomeDiv4"  style="display:none;">
                
                  <form class="form-inline" action="{{ route('add.certificate.outerborderstyle') }}" method="post" enctype="multipart/form-data">
                  @csrf
                  <input type="hidden" id="certititle" name="outer_border_style" value="outer_border_style"><br>
                    <div class="form-group">
                    <p style="color: red;">Manage certificate outer border design.</p>
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo4"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br><br>
                    <div id="demo4" class="collapse">

                    <div class="form-group">
                    <label for="fname">Border:</label><br>
                    <!-- <input type="text" id="titlehight" name="border"> -->
                    <select class="form-control" name="border">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>
                    <div class="form-group">
                  <label for="fname">Width:</label><br>
                  <!-- <input type="text" id="titlewidth" name="titlewidth"> -->
                  <select class="form-control" name="titlewidth">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Hieght:</label><br>
                  <!-- <input type="text" name="titlehight"> -->
                  <select class="form-control" name="titlehight">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin</label><br>
                  <!-- <input type="text" id="marginleft" name="margin"> -->
                  <select class="form-control" name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Top:</label><br>
                  <!-- <input type="text" id="marginleft" name="margintop"> -->
                  <select class="form-control" name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Bottom:</label><br>
                  <!-- <input type="text" id="marginright" name="marginbottom"> -->
                  <select class="form-control" name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Left:</label><br>
                  <!-- <input type="text" id="marginleft" name="marginleft"> -->
                  <select class="form-control" name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Right:</label><br>
                  <!-- <input type="text" name="marginright"> -->
                  <select class="form-control" name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding:</label><br>
                  <!-- <input type="text" id="paddingleft" name="padding"> -->
                  <select class="form-control" name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Top:</label><br>
                  <!-- <input type="text" id="paddingright" name="paddingtop"> -->
                  <select class="form-control" name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Bottom:</label><br>
                  <!-- <input type="text" id="paddingright" name="paddingbottom"> -->
                  <select class="form-control" name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Left:</label><br>
                  <!-- <input type="text" name="paddingleft"> -->
                  <select class="form-control" name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Right:</label><br>
                  <!-- <input type="text" id="paddingright" name="paddingright"> -->
                  <select class="form-control" name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                    <div class="form-group">
                    <label for="fname">Border Top Color:</label><br>
                    <input type="color" id="paddingright" name="border_top_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Border Bottom Color:</label><br>
                    <input type="color" id="paddingright" name="border_bottom_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Border Left Color:</label><br>
                    <input type="color" name="border_left_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Border Right Color:</label><br>
                    <input type="color" name="border_right_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Background Color:</label><br>
                    <input type="color" name="background_color">
                    </div><br><br>
                    
                    </div><br>
                    <div class="form-group">
                    <input class="text-info" type="submit" value="save">
                    </div>
                    </form>
                </div>
                <!-- === outer border end  ===-->

                <!-- == outer sub border start === -->
                <div id="welcomeDiv5"  style="display:none;">
                
                  <form class="form-inline" action="{{ route('add.certificate.outersubborder') }}" method="post" enctype="multipart/form-data">
                  @csrf
                  <input type="hidden" id="certititle" name="outer_sub_border_style" value="outer_sub_border_style"><br>
                    <div class="form-group">
                    <p style="color: red;">Manage certificate outer sub border design.</p>
                    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo5"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                    </div><br><br>
                    <div id="demo5" class="collapse">


                      <div class="form-group">
                    <label for="fname">Border:</label><br>
                    <select class="form-control" name="border">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>
                    <div class="form-group">
                  <label for="fname">Width:</label><br>
                  <select class="form-control" name="titlewidth">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Hieght:</label><br>
                  <select class="form-control" name="titlehight">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin</label><br>
                  <select class="form-control" name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Top:</label><br>
                  <select class="form-control" name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Bottom:</label><br>
                  <select class="form-control" name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Left:</label><br>
                  <select class="form-control" name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Right:</label><br>
                  <select class="form-control" name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding:</label><br>
                  <select class="form-control" name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Top:</label><br>
                  <select class="form-control" name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Bottom:</label><br>
                  <select class="form-control" name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Left:</label><br>
                  <select class="form-control" name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Padding Right:</label><br>
                  <select class="form-control" name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                    <div class="form-group">
                    <label for="fname">Border Top Color:</label><br>
                    <input type="color" id="paddingright" name="border_top_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Border Bottom Color:</label><br>
                    <input type="color" id="paddingright" name="border_bottom_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Border Left Color:</label><br>
                    <input type="color" id="paddingleft" name="border_left_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Border Right Color:</label><br>
                    <input type="color" id="paddingright" name="border_right_color">
                    </div>
                    <div class="form-group">
                    <label for="fname">Background Color:</label><br>
                    <input type="color" id="paddingright" name="background_color">
                    </div>
        
                    </div><br> 
                    <div class="form-group">
                    <input type="submit" value="save">
                    </div>
                    </form>
                </div>
                <!-- === outer sub border end  ===-->

                 <!-- == Inner border start === -->
                 <div id="welcomeDiv6"  style="display:none;">
                      <form class="form-inline" action="{{ route('add.certificate.innerborder') }}" method="post" enctype="multipart/form-data">
                      @csrf
                      <input type="hidden" id="certititle" name="inner_border_style" value="inner_border_style"><br>
                      <div class="form-group">
                      <p style="color: red;">Manage certificate inner border design.</p>
                      <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo6"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                      </div><br><br>
                      <div id="demo6" class="collapse">

                      <div class="form-group">
                      <label for="fname">Border:</label><br>
                      <select class="form-control" name="border">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                      </div>
                     
                      <div class="form-group">
                      <label for="fname">Padding:</label><br>
                      <select class="form-control" name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                      </div>
                     
                      </div><br> 
                      <div class="form-group">
                      <input type="submit" value="save">
                      </div>
                      </form>
                </div>
              <!-- === Inner border end  ===-->

               <!-- == Inner sub border start === -->
               <div id="welcomeDiv7"  style="display:none;">
                  <form class="form-inline" action="{{ route('add.certificate.innersubborder') }}" method="post" enctype="multipart/form-data">
                  @csrf
                  <input type="hidden" id="certititle" name="inner_sub_border_style" value="inner_sub_border_style"><br>
                  
                  <div class="form-group">
                  <p style="color: red;">Manage certificate inner sub border design.</p>
                  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo7"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                  </div><br><br>
                  <div id="demo7" class="collapse">

                 <div class="form-group">
                      <label for="fname">Border:</label><br>
                      <select class="form-control" name="border">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                      </div>
                        <div class="form-group">
                        <label for="fname">Padding:</label><br>
                        <select class="form-control" name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                        </div>
                  
                  <div class="form-group">
                  <label for="fname">Margin Top:</label><br>
                  <select class="form-control" name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Bottom:</label><br>
                  <select class="form-control" name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Left:</label><br>
                  <select class="form-control" name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label for="fname">Margin Right:</label><br>
                  <select class="form-control" name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>
                  
                  
                  </div><br> 
                  <div class="form-group">
                  <input type="submit" value="save">
                  </div>
                  </form>
              </div>
              <!-- === Inner Sub border end  ===-->

              <!-- == certificate background start === -->
              <div id="welcomeDiv8"  style="display:none;">
              <div class="row">
                  <div class="col-md-6">
                  <form class="form-inline" action="{{ route('add.certificate.backgroundstyle') }}" method="post" enctype="multipart/form-data">
                  @csrf
                 
                  <div class="form-group">
                  
                    <label for="fname">Add certificate background Image:</label><br>
                    <input type="file" name="certibackgroundimage">
                    <input type="hidden" id="certititle" name="certificate_background_style" value="certificate_background_style"><br>
                  </div><br>
                 
                
                  
                  
                  <div class="form-group">
                  <p style="color: red;">Manage certificate background design.</p>
                  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo8"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                  </div><br><br>

                  <div id="demo8" class="collapse">
                    <div class="form-group">
                    <label for="fname">Width:</label><br>
                    <select class="form-control" name="titlewidth">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>
                    <div class="form-group">
                    <label for="fname">Hieght:</label><br>
                    <select class="form-control" name="titlehight">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                    </div>
                   
                    <div class="form-group">
                    <label for="fname">Background Color:</label><br>
                    <input type="color" id="paddingright" name="background_color">
                    </div>
                  </div>
                  <div class="form-group">
                  <input type="submit" value="save">
                  </div>
                  </form>
                  </div>
                  <div class="col-md-6">
                  <?php if(!empty($certificatebackgroundstyle->certi_background_image)){?>
                  <img src="{{ asset('admin/certificate_pic/'.$certificatebackgroundstyle->certi_background_image ) }}" class="img-fluid" alt="logo"><br><br>
                  <a href='delete-image/{{ $certificatebackgroundstyle->id }}' > <button class="btn btn-danger btn-sm" title="Delete">Remove</button></a>
                  <?php }?>
                  </div>
                  </div>



              </div>
              <!-- === certificate background end  ===-->

               <!-- == add signature start === -->
               <div id="welcomeDiv11"  style="display:none;">
                <div class="row">
                <div class="col-md-6">
                <form class="form-inline" action="{{ route('add.certificate.signaturestyle') }}" method="post" enctype="multipart/form-data">
                @csrf
               
                <div class="form-group">
                  <label for="fname">Add Signature on certificate:</label><br>
                  <input type="file" name="signatureimage">
                  <input type="hidden" id="certititle" name="certificate_signature_style" value="certificate_signature_style"><br>
                </div><br>

                <div class="form-group">
                <p style="color: red;">Manage signature style.</p>
                <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo11"><i class="fa fa-plus" aria-hidden="true"></i>Add Style</button>
                </div><br><br>

                <div id="demo11" class="collapse">

                  <div class="form-group">
                  <label for="fname">Width:</label><br>
                  <select class="form-control" name="titlewidth">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Hieght:</label><br>
                  <select class="form-control" name="titlehight">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Margin</label><br>
                  <select class="form-control" name="margin">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Margin Top:</label><br>
                  <select class="form-control" name="margintop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Margin Bottom:</label><br>
                  <select class="form-control" name="marginbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Margin Left:</label><br>
                  <select class="form-control" name="marginleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Margin Right:</label><br>
                  <select class="form-control" name="marginright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding:</label><br>
                  <select class="form-control" name="padding">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Top:</label><br>
                  <select class="form-control" name="paddingtop">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Bottom:</label><br>
                  <select class="form-control" name="paddingbottom">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Left:</label><br>
                  <select class="form-control" name="paddingleft">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                  <div class="form-group">
                  <label for="fname">Padding Right:</label><br>
                  <select class="form-control" name="paddingright">
                        <option value="" >Select</option>
                        <option value="1px" >1px</option>
                        <option value="2px">2px</option>
                        <option value="3px">3px</option>
                        <option value="4px">4px</option>
                        <option value="5px" >5px</option>
                        <option value="6px">6px</option>
                        <option value="7px">7px</option>
                        <option value="8px">8px</option>
                        <option value="9px" >9px</option>
                        <option value="10px">10px</option>
                        <option value="11px">11px</option>
                        <option value="12px">12px</option>
                        <option value="13px" >13px</option>
                        <option value="14px">14px</option>
                        <option value="15px">15px</option>
                        <option value="16px">16px</option>
                        <option value="17px" >17px</option>
                        <option value="18px">18px</option>
                        <option value="19px">19px</option>
                        <option value="20px">20px</option>
                        <option value="21px" >21px</option>
                        <option value="22px">22px</option>
                        <option value="23px">23px</option>
                        <option value="24px">24px</option>
                        <option value="25px" >25px</option>
                        <option value="26px">26px</option>
                        <option value="27px">27px</option>
                        <option value="28px" >28px</option>
                        <option value="29px">29px</option>
                        <option value="30px">30px</option>
                        <option value="31px">31px</option>
                        <option value="32px" >32px</option>
                        <option value="33px">33px</option>
                        <option value="34px">34px</option>
                        <option value="35px">35px</option>
                    </select>
                  </div>

                </div>
                <div class="form-group">
                <input type="submit" value="save">
                </div>
                </form>
                </div>
                <div class="col-md-6">
                <?php if(!empty($certificatesignaturestyle->signature_image)){?>
                  <img src="{{ asset('admin/certificate_pic/'.$certificatesignaturestyle->signature_image ) }}" class="img-fluid" alt="logo"><br><br>
                  <a href='delete-signature/{{ $certificatesignaturestyle->id }}' > <button class="btn btn-danger btn-sm" title="Delete">Remove</button></a>
                  <?php }?>
                </div>
                <div>


            </div>
            <!-- === add signature end  ===-->
      
    </div>
    
  </div>
</div>

</body>
</html>
<!-- = js for certificate start== -->
<script>
  function showDiv1() {
    document.getElementById('welcomeDiv1').style.display = "block";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";
}

function showDiv2() {
    document.getElementById('welcomeDiv2').style.display = "block";
    document.getElementById('welcomeDiv1').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";
}

function showDiv3() {
    document.getElementById('welcomeDiv3').style.display = "block";
    document.getElementById('welcomeDiv1').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";
}

function showDiv4() {
    document.getElementById('welcomeDiv4').style.display = "block"; 
    document.getElementById('welcomeDiv1').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";
}

function showDiv5() {
    document.getElementById('welcomeDiv5').style.display = "block";
    document.getElementById('welcomeDiv1').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";
}

function showDiv6() {
    document.getElementById('welcomeDiv6').style.display = "block";
    document.getElementById('welcomeDiv1').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";
}

function showDiv7() {
    document.getElementById('welcomeDiv7').style.display = "block";
    document.getElementById('welcomeDiv1').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv11').style.display = "none";   
}

function showDiv8() {
    document.getElementById('welcomeDiv8').style.display = "block";
    document.getElementById('welcomeDiv11').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv1').style.display = "none";
}

function showDiv9() {
    document.getElementById('welcomeDiv9').style.display = "block";
    document.getElementById('welcomeDiv11').style.display = "none";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv1').style.display = "none";
}

function showDiv10() {
    document.getElementById('welcomeDiv10').style.display = "block";
    document.getElementById('welcomeDiv11').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv1').style.display = "none";
}

function showDiv11() {
    document.getElementById('welcomeDiv11').style.display = "block";
    document.getElementById('welcomeDiv10').style.display = "none";
    document.getElementById('welcomeDiv9').style.display = "none";
    document.getElementById('welcomeDiv8').style.display = "none";
    document.getElementById('welcomeDiv7').style.display = "none";
    document.getElementById('welcomeDiv6').style.display = "none";
    document.getElementById('welcomeDiv5').style.display = "none";
    document.getElementById('welcomeDiv4').style.display = "none";
    document.getElementById('welcomeDiv3').style.display = "none";
    document.getElementById('welcomeDiv2').style.display = "none";
    document.getElementById('welcomeDiv1').style.display = "none";
}

</script>
<!-- = js for certificate start == -->