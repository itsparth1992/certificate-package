<style type="text/css">
  /* css for side menu start */
.vertical-menu {
  width: 200px;
}

.vertical-menu a {
  background-color: #eee;
  color: black;
  display: block;
  padding: 12px;
  text-decoration: none;
}

.vertical-menu a:hover {
  background-color: #ccc;
}

.vertical-menu a.active {
  background-color: #4CAF50;
  color: white;
}
/* css for side menu end */

/* css for certificate design start */

.cirtificate-border-one { 
    font-family: "Times New Roman", Times, serif; 
    border: 15px solid ;
    border-top-color:  #40444a;
    border-right-color: #0284a2;
    border-bottom-color: #0284a2;
    border-left-color: #40444a;
    padding:20px;
    background-color: #fff;
  
  }
  .cirtificate-border-one-sub { 
    font-family: "Times New Roman", Times, serif; 
    border: 7px solid ;
    border-top-color:  #0284a2;
    border-right-color: #40444a;
    border-bottom-color: #40444a;
    border-left-color: #0284a2;
    padding:20px;
    background-color: #fff;
    margin-top: -29px;
    margin-left: -29px;
    margin-bottom: -29px;
    margin-right: -29px;
  
  }
  .cirtificate-border-two {  
    border: 2px solid #0284a2;
    padding:20px;
  }

  .cirtificate-border-two-sub {  
    border: 2px solid #0284a2;
    padding:20px;
    margin-top: -26px;
    margin-left: -26px;
    margin-bottom: -26px;
    margin-right: -26px;
  }
  .cirtificate-heading {
    font-size:50px; 
    font-weight:bold;
    font-style: italic;
    margin-bottom: 20px;
  }
  .cirtificate-detail {
    margin-bottom: 20px;
    font-size: 30px;
  }
  .cirtificate-instructor {
    font-family: 'Great Vibes';
    font-style: normal;
    font-size: 20px;
    margin: 0 auto;
    text-align: center;
  }
  .cirtificate-logo img {
    width: 125px;
  }
  
  .img-fluid {
      max-width: 100%;
      height: auto;
  }
  .box-body img {
      height: 39px;
  }
  
/* css for certificate design end */

/* toggle button setting start */
/* The switch - the box around the slider */

.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
/* toggle button setting end  */

</style>
<section class="content">
  
  <div class="box">
  	<div class="box-header with-border">
  		<div class="box-title">
  			
  		</div>

  		<a title="Create a new meeting" href="{{ route('create.certificate') }}" class="pull-right btn btn-md btn-info">
  			<i class="fa fa-plus"></i> Create Certificate
  		</a>
  	</div>

  	<div class="box-body">
		<!-- == certificate template start == -->
		<div class="container">
        <div class="row">
		<div class="col-lg-9">
		<div class="cirtificate-border-one text-center">
		<div class="cirtificate-border-one-sub text-center">
                    <div class="cirtificate-border-two">
					<div class="cirtificate-border-two-sub">
                       <div class="cirtificate-heading" style=""> {{ __('frontstaticword.CertificateofCompletion') }}</div>
                        @php
                            $mytime = Carbon\Carbon::now();
                        @endphp
                       <p class="cirtificate-detail" style="font-size:30px"> {{ __('frontstaticword.Thisistocertifythat') }}<b> Admin Example </b>  {{ __('frontstaticword.successfullycompleted') }} <b> The Complete Web Developer Bootcamp </b> {{ __('frontstaticword.onlinecourseon') }} <br>
                       
                        <span style="font-size:25px">16th November 2020</span>
                        
                        </p>

                       <span class="cirtificate-instructor">Admin Example</span>
                       <br>
                       <span class="cirtificate-one">Admin Example, {{ __('frontstaticword.Instructor') }}</span>
                       <br>
                       <span>&</span>
                       <div class="cirtificate-logo">
                        @if($gsetting['logo_type'] == 'L')
                            <img src="{{ asset('images/logo/'.$gsetting['logo']) }}" class="img-fluid" alt="logo">
                        @else()
                            <a href="#"><b><div class="logotext">project_title</div></b></a>
                        @endif
                      </div>
                      
                    </div>
					</div>
					</div>
                </div>
		</div>
		<div class="col-lg-3">
		</div>
		</div>
		</div>
		<!-- == certificate template end == -->
  		<div class="text-center"></div>

  	</div>
  </div>
</section>
