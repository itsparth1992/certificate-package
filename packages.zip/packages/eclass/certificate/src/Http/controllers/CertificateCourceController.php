<?php

namespace Eclass\Certificate\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Eclass\Certificate\Models\CertificateDesign;



class CertificateCourceController extends Controller
{
    public function dashboard()
    {
    
        return view('Certificate::dashboard');
    }

    public function certificatesample()
    {

        return view('Certificate::sample_certificate');
    }

    public function create()
    {
        return view('Certificate::create_certificate');
    }

      // ==== logo start ===
    public function addlogo(Request $request)
    {
        // echo "test";
        // exit;
        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','logo_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->logo_style;

            if(!empty($request->border)){
                $addCertificateDesign->border=$request->border;
            }
            if(!empty($request->titlewidth)){
            $addCertificateDesign->width=$request->titlewidth;
            }
            if(!empty($request->titlehight)){
            $addCertificateDesign->height=$request->titlehight;
            }
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }
            if(!empty($request->logomage)){
                if ($request->hasFile('logomage'))
                {
                $image = $request->file('logomage');
                $name = $image->getClientOriginalName();
                $destinationPath = public_path('/admin/certificate_pic');
                $image->move($destinationPath, $name);
                $addCertificateDesign->logo_image = $name;
                }
            }
            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->logo_style;
            $addCertificateDesign->width=$request->titlewidth;
            $addCertificateDesign->height=$request->titlehight;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
            $addCertificateDesign->user_id = $userid;

            if ($request->hasFile('logomage'))
            {
             $image = $request->file('logomage');
             $name = $image->getClientOriginalName();
             $destinationPath = public_path('/admin/certificate_pic');
             $image->move($destinationPath, $name);
             $addCertificateDesign->logo_image = $name;
            }
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');
       
       
    }
    // ==== logo end =====

    // ==== title start ====
    public function addtitle(Request $request)
    {
        // echo "test";
        // exit;
        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','title_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->title_style;
            if(!empty($request->certititle)){
            $addCertificateDesign->title=$request->certititle;
            }
            if(!empty($request->titlewidth)){
            $addCertificateDesign->width=$request->titlewidth;
            }
            if(!empty($request->titlehight)){
            $addCertificateDesign->height=$request->titlehight;
            }
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }

            if(!empty($request->font_size)){
            $addCertificateDesign->font_size=$request->font_size;
            }
            if(!empty($request->font_weight)){
            $addCertificateDesign->font_weight=$request->font_weight;
            }
            if(!empty($request->font_style)){
            $addCertificateDesign->font_style=$request->font_style;
            }

            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->title_style;
            $addCertificateDesign->title=$request->certititle;
            $addCertificateDesign->width=$request->titlewidth;
            $addCertificateDesign->height=$request->titlehight;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
            $addCertificateDesign->font_size=$request->font_size;
            $addCertificateDesign->font_weight=$request->font_weight;
            $addCertificateDesign->font_style=$request->font_style;
            $addCertificateDesign->user_id = $userid;

            $addCertificateDesign->save();
        }
         return redirect()->back()->with('success','Style Applied successfully');
    }

    // ==== title end ==========

    // ==== certificate background start ======
    public function addcertificatebackground(Request $request)
    {

        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','certificate_background_style')->where('user_id', $userid)->first();

        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->certificate_background_style;
            
            if(!empty($request->titlewidth)){
            $addCertificateDesign->width=$request->titlewidth;
            }
            if(!empty($request->titlehight)){
            $addCertificateDesign->height=$request->titlehight;
            }
            
            if ($request->hasFile('certibackgroundimage'))
            {
             $image = $request->file('certibackgroundimage');
             $name = $image->getClientOriginalName();
             $destinationPath = public_path('/admin/certificate_pic');
             $image->move($destinationPath, $name);
             $addCertificateDesign->certi_background_image = $name;
            }
            

            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->certificate_background_style;
            $addCertificateDesign->width=$request->titlewidth;
            $addCertificateDesign->height=$request->titlehight;
            $addCertificateDesign->background_color=$request->background_color;
            $addCertificateDesign->user_id = $userid;

            if ($request->hasFile('certibackgroundimage'))
            {
             $image = $request->file('certibackgroundimage');
             $name = $image->getClientOriginalName();
             $destinationPath = public_path('/admin/certificate_pic');
             $image->move($destinationPath, $name);
             $addCertificateDesign->certi_background_image = $name;
            }
             $addCertificateDesign->save();
        }
         return redirect()->back()->with('success','Style Applied successfully'); 
    }

    // ==== certificate background end ========

     // ==== certificate signature start =======
    public function addcertificatesignature(Request $request)
    {

        
        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','certificate_signature_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->certificate_signature_style;
            
            if(!empty($request->titlewidth)){
            $addCertificateDesign->width=$request->titlewidth;
            }
            if(!empty($request->titlehight)){
            $addCertificateDesign->height=$request->titlehight;
            }
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }
            if(!empty($request->signatureimage)){
                if ($request->hasFile('signatureimage'))
                {
                $image = $request->file('signatureimage');
                $name = $image->getClientOriginalName();
                $destinationPath = public_path('/admin/certificate_pic');
                $image->move($destinationPath, $name);
                $addCertificateDesign->signature_image = $name;
                }
            }

            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->certificate_signature_style;
            $addCertificateDesign->width=$request->titlewidth;
            $addCertificateDesign->height=$request->titlehight;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
            $addCertificateDesign->user_id = $userid;

            if ($request->hasFile('signatureimage'))
            {
             $image = $request->file('signatureimage');
             $name = $image->getClientOriginalName();
             $destinationPath = public_path('/admin/certificate_pic');
             $image->move($destinationPath, $name);
             $addCertificateDesign->signature_image = $name;
            }
            $addCertificateDesign->save();
        }
         return redirect()->back()->with('success','Style Applied successfully'); 
    }
    // ==== certificate signature end =========

    // === content block 1 start ======
    public function addcontent(Request $request)
    {
        
        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','Content_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->Content_style;
            if(!empty($request->certicontent)){
                $addCertificateDesign->content=$request->certicontent;
            }
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }
            if(!empty($request->font_size)){
                $addCertificateDesign->font_size=$request->font_size;
            }

            $addCertificateDesign->save();

        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->Content_style;
            $addCertificateDesign->content=$request->certicontent;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
            $addCertificateDesign->font_size=$request->font_size;

            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');
        // return view('admin.certificate.create');
       
    }

    // === content block 1 end ======

     // === content block 2 start ======
    public function addcontent2(Request $request)
    {
        
       $userid = 2;
       
        $addCertificateDesign = CertificateDesign::where('style_title','content_style_block2')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->content_style_block2;
            if(!empty($request->certicontent2)){
            $addCertificateDesign->content = $request->certicontent2;
            }
           
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }

            if(!empty($request->font_family)){
            $addCertificateDesign->font_family=$request->font_family;
            }
            if(!empty($request->font_size)){
            $addCertificateDesign->font_size=$request->font_size;
            }
            if(!empty($request->font_weight)){
            $addCertificateDesign->font_weight=$request->font_weight;
            }
            if(!empty($request->font_style)){
            $addCertificateDesign->font_style=$request->font_style;
            }
            if(!empty($request->text_align)){
            $addCertificateDesign->text_align=$request->text_align;
            }
            $addCertificateDesign->user_id = $userid;
            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->content_style_block2;
            $addCertificateDesign->content = $request->certicontent2;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
            $addCertificateDesign->font_family=$request->font_family;
            $addCertificateDesign->font_size=$request->font_size;
            $addCertificateDesign->font_weight=$request->font_weight;
            $addCertificateDesign->font_style=$request->font_style;
            $addCertificateDesign->text_align=$request->text_align;
            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');  
    }
    // === content block 2 end ======

    // === content block 3 start ====
    public function addcontent3(Request $request)
    {
        
        $userid = 2;
        
        $addCertificateDesign = CertificateDesign::where('style_title','content_style_block3')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->content_style_block3;
            if(!empty($request->certicontent3)){
            $addCertificateDesign->content = $request->certicontent3;
            }
            if(!empty($request->margin)){
                $addCertificateDesign->margin=$request->margin;
                }
                if(!empty($request->margintop)){
                $addCertificateDesign->margin_top=$request->margintop;
                }
                if(!empty($request->marginbottom)){
                $addCertificateDesign->margin_bottom=$request->marginbottom;
                }
                if(!empty($request->marginleft)){
                $addCertificateDesign->margin_left=$request->marginleft;
                }
                if(!empty($request->marginright)){
                $addCertificateDesign->margin_right=$request->marginright;
                }
                if(!empty($request->padding)){
                $addCertificateDesign->padding=$request->padding;
                }
                if(!empty($request->paddingtop)){
                $addCertificateDesign->padding_top=$request->paddingtop;
                }
                if(!empty($request->paddingbottom)){
                $addCertificateDesign->padding_bottom=$request->paddingbottom;
                }
                if(!empty($request->paddingleft)){
                $addCertificateDesign->padding_left=$request->paddingleft;
                }
                if(!empty($request->paddingright)){
                $addCertificateDesign->padding_right=$request->paddingright;
                }
                if(!empty($request->font_family)){
                $addCertificateDesign->font_family=$request->font_family;
                }
                if(!empty($request->font_size)){
                $addCertificateDesign->font_size=$request->font_size;
                }
                if(!empty($request->font_weight)){
                $addCertificateDesign->font_weight=$request->font_weight;
                }
                if(!empty($request->font_style)){
                $addCertificateDesign->font_style=$request->font_style;
                }
                if(!empty($request->text_align)){
                $addCertificateDesign->text_align=$request->text_align;
                }
                $addCertificateDesign->user_id = $userid;
            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->content_style_block3;
            $addCertificateDesign->content = $request->certicontent3;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
            $addCertificateDesign->font_family=$request->font_family;
            $addCertificateDesign->font_size=$request->font_size;
            $addCertificateDesign->font_weight=$request->font_weight;
            $addCertificateDesign->font_style=$request->font_style;
            $addCertificateDesign->text_align=$request->text_align;
            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');
    }

    // === content block 3 end ====

    // ==== outerborder start ===
    public function addouterborder(Request $request)
    {
        
        $userid = 2;
        
        $addCertificateDesign = CertificateDesign::where('style_title','outer_border_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->outer_border_style;
            
            if(!empty($request->border)){
                $addCertificateDesign->border=$request->border;
            }
            if(!empty($request->titlewidth)){
            $addCertificateDesign->width=$request->titlewidth;
            }
            if(!empty($request->titlehight)){
            $addCertificateDesign->height=$request->titlehight;
            }
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }
            if(!empty($request->border_top_color)){
            $addCertificateDesign->border_top_color=$request->border_top_color;
            }
            if(!empty($request->border_bottom_color)){
            $addCertificateDesign->border_bottom_color=$request->border_bottom_color;
            }
            if(!empty($request->border_left_color)){
            $addCertificateDesign->border_left_color=$request->border_left_color;
            }
            if(!empty($request->border_right_color)){
            $addCertificateDesign->border_right_color=$request->border_right_color;
            }
            if(!empty($request->background_color)){
            $addCertificateDesign->background_color=$request->background_color;
            }

            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->outer_border_style;
            $addCertificateDesign->border=$request->border;
            $addCertificateDesign->width=$request->titlewidth;
            $addCertificateDesign->height=$request->titlehight;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
    
            $addCertificateDesign->border_top_color=$request->border_top_color;
            $addCertificateDesign->border_bottom_color=$request->border_bottom_color;
            $addCertificateDesign->border_left_color=$request->border_left_color;
            $addCertificateDesign->border_right_color=$request->border_right_color;
            $addCertificateDesign->background_color=$request->background_color;
            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');
        // return view('admin.certificate.create');
       
       
    }
// === outer border end ======

// === outer sub border start ===
    public function addoutersubborder(Request $request)
    {
        
        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','outer_sub_border_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->outer_sub_border_style;

            if(!empty($request->border)){
                $addCertificateDesign->border=$request->border;
            }
            if(!empty($request->titlewidth)){
            $addCertificateDesign->width=$request->titlewidth;
            }
            if(!empty($request->titlehight)){
            $addCertificateDesign->height=$request->titlehight;
            }
            if(!empty($request->margin)){
            $addCertificateDesign->margin=$request->margin;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            if(!empty($request->paddingtop)){
            $addCertificateDesign->padding_top=$request->paddingtop;
            }
            if(!empty($request->paddingbottom)){
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            }
            if(!empty($request->paddingleft)){
            $addCertificateDesign->padding_left=$request->paddingleft;
            }
            if(!empty($request->paddingright)){
            $addCertificateDesign->padding_right=$request->paddingright;
            }
            if(!empty($request->border_top_color)){
            $addCertificateDesign->border_top_color=$request->border_top_color;
            }
            if(!empty($request->border_bottom_color)){
            $addCertificateDesign->border_bottom_color=$request->border_bottom_color;
            }
            if(!empty($request->border_left_color)){
            $addCertificateDesign->border_left_color=$request->border_left_color;
            }
            if(!empty($request->border_right_color)){
            $addCertificateDesign->border_right_color=$request->border_right_color;
            }
            if(!empty($request->background_color)){
            $addCertificateDesign->background_color=$request->background_color;
            }

            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->outer_sub_border_style;
            $addCertificateDesign->border=$request->border;
            $addCertificateDesign->width=$request->titlewidth;
            $addCertificateDesign->height=$request->titlehight;
            $addCertificateDesign->margin=$request->margin;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->padding_top=$request->paddingtop;
            $addCertificateDesign->padding_bottom=$request->paddingbottom;
            $addCertificateDesign->padding_left=$request->paddingleft;
            $addCertificateDesign->padding_right=$request->paddingright;
    
            $addCertificateDesign->border_top_color=$request->border_top_color;
            $addCertificateDesign->border_bottom_color=$request->border_bottom_color;
            $addCertificateDesign->border_left_color=$request->border_left_color;
            $addCertificateDesign->border_right_color=$request->border_right_color;
            $addCertificateDesign->background_color=$request->background_color;
            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');
        // return view('admin.certificate.create');
       
    }
// === outer sub border end ===


// === inner border start ===
    public function addinnerborder(Request $request)
    {
        
        $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','inner_border_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->inner_border_style;

            if(!empty($request->border)){
                $addCertificateDesign->border=$request->border;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->inner_border_style;
            $addCertificateDesign->border=$request->border;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully');
        // return view('admin.certificate.create');
       
    }
// ==== inner border end =====

// ==== inner sub border start ===
    public function addinnersubborder(Request $request)
    {
        
       $userid = 2;
        $addCertificateDesign = CertificateDesign::where('style_title','inner_sub_border_style')->where('user_id', $userid)->first();
        
        if(!empty($addCertificateDesign)){
            $addCertificateDesign->style_title = $request->inner_sub_border_style;

            if(!empty($request->border)){
                $addCertificateDesign->border=$request->border;
            }
            if(!empty($request->margintop)){
            $addCertificateDesign->margin_top=$request->margintop;
            }
            if(!empty($request->marginbottom)){
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            }
            if(!empty($request->marginleft)){
            $addCertificateDesign->margin_left=$request->marginleft;
            }
            if(!empty($request->marginright)){
            $addCertificateDesign->margin_right=$request->marginright;
            }
            if(!empty($request->padding)){
            $addCertificateDesign->padding=$request->padding;
            }
            
            $addCertificateDesign->save();
        }else{
            $addCertificateDesign = new CertificateDesign;
            $userid = 2;
            $addCertificateDesign->style_title = $request->inner_sub_border_style;
            $addCertificateDesign->border=$request->border;
            $addCertificateDesign->margin_top=$request->margintop;
            $addCertificateDesign->margin_bottom=$request->marginbottom;
            $addCertificateDesign->margin_left=$request->marginleft;
            $addCertificateDesign->margin_right=$request->marginright;
            $addCertificateDesign->padding=$request->padding;
            $addCertificateDesign->user_id = $userid;
        
             $addCertificateDesign->save();
        }
       
         return redirect()->back()->with('success','Style Applied successfully'); 
    }

// ==== inner sub border end
// ==== certificate preview start ==========
    public function previewcertificate()
    {
       // echo "test";
       // exit;
       $userid = 2;
       
        $logostyle = CertificateDesign::where([
            ['user_id', '=', $userid],
            ['style_title', '=', 'logo_style']
        ])->first();

        
        $titlestyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'title_style']
                ])->first();

       
        $contentstyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'content_style']
                ])->first();
        $contentstyleblock2 = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'content_style_block2']
                ])->first();
        $contentstyleblock3 = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'content_style_block3']
                ])->first();
        $outerborderstyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'outer_border_style']
                ])->first();
        
        $outersubborderstyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'outer_sub_border_style']
                ])->first();

        $innerborderstyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'inner_border_style']
                ])->first();

        $innersubborderstyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'inner_sub_border_style']
                ])->first();

        $certificatebackgroundstyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'certificate_background_style']
                ])->first();

        // print_r($certificatebackgroundstyle);
        // exit;
        
        $certificatesignaturestyle = CertificateDesign::where([
                    ['user_id', '=', $userid],
                    ['style_title', '=', 'certificate_signature_style']
                ])->first();

        

        return view('Certificate::certificate_preview', compact('logostyle','titlestyle', 
                    'contentstyle', 'contentstyleblock2', 'contentstyleblock3',
                    'outerborderstyle', 'outersubborderstyle','innerborderstyle',
                    'innersubborderstyle','certificatebackgroundstyle',
                    'certificatesignaturestyle'));  
        // return view('Certificate::certificate_preview', compact('detail'));
    }
// ========= certificate preview end ===============

// ========= certificate setting start ==============

public function addcertifisetting($settingdata)
    {
        $userid = 2;
        
        $addsettingdata = CertificateDesign::where('user_id', $userid)->get();
        // dd($addsettingdata);
        foreach($addsettingdata as $addsettingdatas){
            $addsettingdatas->setting = $settingdata;
            $addsettingdatas->save();
        }
        return redirect()->back()->with('success','Setting Applied successfully');  
    }
// ========== certificate setting end ============


    public function certifisetting($settingdata)
    {
        // $userid = Auth::user()->id;
        $userid = 1;
        $addsettingdata = CertificateDesign::where('user_id', $userid)->get();
        // dd($addsettingdata);
        foreach($addsettingdata as $addsettingdatas){
            $addsettingdatas->setting = $settingdata;
            $addsettingdatas->save();
        }
        return redirect()->back()->with('success','Setting Applied successfully');  
    }

    

}