<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCertificatedesignsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('certificatedesigns', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
			$table->string('slug')->nullable();
			$table->string('border')->nullable();

            $table->string('width')->nullable();
			$table->string('height')->nullable();
			
            $table->string('margin')->nullable();
            $table->string('margin_top')->nullable();
			$table->string('margin_bottom')->nullable();
			$table->string('margin_left')->nullable();
            $table->string('margin_right')->nullable();

            $table->string('padding')->nullable();
            $table->string('padding_top')->nullable();
            $table->string('padding_bottom')->nullable();
			$table->string('padding_left')->nullable();
            $table->string('padding_right')->nullable();
            

            $table->string('border_top_color')->nullable();
            $table->string('border_bottom_color')->nullable();
			$table->string('border_left_color')->nullable();
            $table->string('border_right_color')->nullable();
			
			$table->string('background_color')->nullable();

			$table->string('font_family')->nullable();
            $table->string('font_size')->nullable();
            $table->string('font_weight')->nullable();
            $table->string('font_style')->nullable();

            $table->string('text_align')->nullable();
            $table->string('text_color')->nullable();
            $table->string('logo_image')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('certificatedesigns');
    }
}
