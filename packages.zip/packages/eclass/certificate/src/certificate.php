<?php


namespace Eclass\Certificate;
class Certificate
{
    public function Certificate(String $sName)
    {
        return 'Hi ' . $sName . '! How are you doing today?';
    }
}