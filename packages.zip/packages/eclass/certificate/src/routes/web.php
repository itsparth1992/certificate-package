<?php

use Eclass\Certificate;

Route::group(['namespace'=>'Eclass\Certificate\Http\Controllers'], function(){

	Route::get('cource-certificate-dashboard', 'CertificateCourceController@dashboard')->name('cource.certificate.dashboard');

	Route::get('cource-certificate-sample', 'CertificateCourceController@certificatesample')->name('cource.certificate.sample');

	Route::get('cource-create-certificate', 'CertificateCourceController@create')->name('courec.create.certificate');

	Route::get('cource-preview-certificate', 'CertificateCourceController@previewcertificate')->name('cource.preview.certificate');

	Route::get('enable-disable-setting/{id}', 'CertificateCourceController@certifisetting')->name('cource.setting.certificate');

// ======= save certificate element ===============

	Route::post('add-certificate-logo', 'CertificateCourceController@addlogo')->name('add.certificate.logostyle');
	Route::post('add-certificate-title', 'CertificateCourceController@addtitle')->name('add.certificate.titlestyle');
	Route::post('add-certificate-background', 'CertificateCourceController@addcertificatebackground')->name('add.certificate.backgroundstyle');
	Route::post('add-certificate-signature', 'CertificateCourceController@addcertificatesignature')->name('add.certificate.signaturestyle');
	Route::post('add-certificate-content', 'CertificateCourceController@addcontent')->name('add.certificate.contentstyle');

	Route::post('add-certificate-content2', 'CertificateCourceController@addcontent2')->name('add.certificate.content2style');
	Route::post('add-certificate-content3', 'CertificateCourceController@addcontent3')->name('add.certificate.content3style');
	Route::post('add-certificate-outerborder', 'CertificateCourceController@addouterborder')->name('add.certificate.outerborderstyle');
	Route::post('add-certificate-outersubborder', 'CertificateCourceController@addoutersubborder')->name('add.certificate.outersubborder');
	Route::post('add-certificate-innerborder', 'CertificateCourceController@addinnerborder')->name('add.certificate.innerborder');

	Route::post('add-certificate-inner-subborder', 'CertificateCourceController@addinnersubborder')->name('add.certificate.innersubborder');

	Route::get('Certificate-setting/{id}', 'CertificateCourceController@addcertifisetting')->name('add.setting.certificate');
	
});


// Route::get('certificate', function(){

// 	 return "test";

// 	return view('Certificate::certificate');

	
// });