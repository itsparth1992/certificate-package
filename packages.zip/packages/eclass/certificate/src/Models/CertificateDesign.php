<?php
// namespace App;
namespace Eclass\Certificate\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CertificateDesign extends Model
{
    // use HasFactory;

    protected $table = 'certificatedesigns';  

    protected $fillable = [
        'title', 'slug','width','height',
        'margin', 'margin_top', 'margin_bottom', 'margin_left', 'margin_right',
        'padding', 'padding_top', 'padding_bottom', 'padding_left', 'padding_right', 
        'border', 'border_top_color', 'border_bottom_color', 'border_left_color', 'border_right_color', 
        'background_color', 'font_family', 'font_size', 'font_weight', 'font_style', 'text_align', 'logo_image'
    ]; 
}
