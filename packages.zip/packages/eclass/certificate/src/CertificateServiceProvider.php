<?php
namespace Eclass\Certificate;
use Illuminate\Support\ServiceProvider;
class CertificateServiceProvider extends ServiceProvider
{

	public function boot()
    {
        $this->loadRoutesFrom(__DIR__.'/routes/web.php');
        $this->loadViewsFrom(__DIR__.'/views', 'Certificate');
        $this->loadMigrationsFrom(__DIR__.'database/migrations');

        
        
        

        $this->publishes([
          
         __DIR__.'/views' => resource_path('views/vendor/certificate'),
          

        ]);

         $this->publishes([
        __DIR__.'/public' => public_path('vendor/certificate'),
            ], 'public');

         $this->publishes([
        __DIR__.'/config/certificate.php' => config_path('certificate.php')
        ], 'config');

    
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        
        // $this->app->make('addon\certificate\CertificateCourceController');
    }

}